﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MG_5_FreelanceJobsite.Models
{
    public class TimeSpecificJobListing
    {
        public List<Job> ForPosting { get; set; }
    }
}