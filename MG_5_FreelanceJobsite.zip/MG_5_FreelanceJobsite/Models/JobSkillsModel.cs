﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MG_5_FreelanceJobsite.Models
{
    public class JobSkillsModel
    {

        public Job myJob{ get; set; }
        public List<String> mySkillNames { get; set; }
        //public String skillName { get; set; }
        //public SkillsLog skillLog { get; set; }
        


    }
}